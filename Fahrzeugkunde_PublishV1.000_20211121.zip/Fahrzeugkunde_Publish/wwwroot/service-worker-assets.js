﻿self.assetsManifest = {
  "assets": [
    {
      "hash": "sha256-8aM9R9K90X6h+KPDW4OzrEh071mAs7dvAQxjBxAZQAc=",
      "url": "css\/app.css"
    },
    {
      "hash": "sha256-rldnE7wZYJj3Q43t5v8fg1ojKRwyt0Wtfm+224CacZs=",
      "url": "css\/bootstrap\/bootstrap.min.css"
    },
    {
      "hash": "sha256-xMZ0SaSBYZSHVjFdZTAT\/IjRExRIxSriWcJLcA9nkj0=",
      "url": "css\/bootstrap\/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-jA4J4h\/k76zVxbFKEaWwFKJccmO0voOQ1DbUW+5YNlI=",
      "url": "css\/open-iconic\/FONT-LICENSE"
    },
    {
      "hash": "sha256-BJ\/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css\/open-iconic\/font\/css\/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh\/chSkSvQpc=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv\/U1xl\/9D3ehyU69JE+FvAcu5HQ+\/a0=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.otf"
    },
    {
      "hash": "sha256-+P1oQ5jPzOVJGC52E1oxGXIXxxCyMlqy6A9cNxGYzVk=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ\/v\/QzXlejRDwUNdZIofI=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.woff"
    },
    {
      "hash": "sha256-aF5g\/izareSj02F3MPSoTGNbcMBl9nmZKDe04zjU\/ss=",
      "url": "css\/open-iconic\/ICON-LICENSE"
    },
    {
      "hash": "sha256-p\/oxU91iBE+uaDr3kYOyZPuulf4YcPAMNIz6PRA\/tb0=",
      "url": "css\/open-iconic\/README.md"
    },
    {
      "hash": "sha256-Jtxf9L+5ITKRc1gIRl4VbUpGkRNfOBXjYTdhJD4facM=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-f0YB6iwyqMjQSRS8yk5jBPcgxNqmH+\/yECVyVvgxQ9Q=",
      "url": "FData\/Bilder\/Fahrzeug1.xlsx_!Links_Grafik 2.jpg"
    },
    {
      "hash": "sha256-ZCqV\/Uf1X2zFyM2pwI9jvKeBZapINYMTQW2U\/Kb3N+E=",
      "url": "FData\/Bilder\/Fahrzeug1.xlsx_!Rechts_Grafik 12.jpg"
    },
    {
      "hash": "sha256-MThT9ms81LCi\/GR2pJfHfZy+q\/MCktk9l90xZbVlx2A=",
      "url": "FData\/Bilder\/Fahrzeug1.xlsx_Default_Grafik 10.jpg"
    },
    {
      "hash": "sha256-m+A8ivJqMtDJLlxu+N25hbxDgEy2uABqc\/XxL4X1CB4=",
      "url": "FData\/Bilder\/Fahrzeug1.xlsx_Default_Grafik 14.jpg"
    },
    {
      "hash": "sha256-f0YB6iwyqMjQSRS8yk5jBPcgxNqmH+\/yECVyVvgxQ9Q=",
      "url": "FData\/Bilder\/Fahrzeug1.xlsx_Default_Grafik 9.jpg"
    },
    {
      "hash": "sha256-n8w0eABKrcFDwChLf6trCv3RBmPVZzn42d\/SR0AT9mc=",
      "url": "FData\/Bilder\/Start.xlsx_Default_Grafik 13.jpg"
    },
    {
      "hash": "sha256-lAJ8mHT21b3Kn5xpBMwmqxjIF7FzYOPQzWHDXhfRQHc=",
      "url": "FData\/Config.json"
    },
    {
      "hash": "sha256-3AGOElrzXd3chv0rUJ4Qtb97CHGmeXQazzl5DEE3xh0=",
      "url": "FData\/Json\/FindAreas.json"
    },
    {
      "hash": "sha256-PHRNrdE6NdvdQJc4xn50nmw6Evl857qK0HpXJtQgRZk=",
      "url": "FData\/Json\/FindObjects.json"
    },
    {
      "hash": "sha256-wrTR9RVmTHdRzge5Ie5Mkd5KtznKPsGRtvwxOEuBNUI=",
      "url": "FData\/Json\/FindPictures.json"
    },
    {
      "hash": "sha256-OWNPnQCPh0jhEUqfDh3ZMDR5UdK3LtvfxBluRyNb6lU=",
      "url": "FData\/xlsxFiles\/Fahrzeug1.xlsx"
    },
    {
      "hash": "sha256-jV5iVpmn6\/iRXu4Vhr0YaHPRhT9FcfYYytt1ZdjvL5U=",
      "url": "FData\/xlsxFiles\/Start.xlsx"
    },
    {
      "hash": "sha256-IpHFcQvs03lh6W54zoeJRG1jW+VnGmwymzxLoXtKX7Y=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-S\/jE+yWuimL\/oJQC6Admpeu19fz\/6fQhvUoXNId\/stw=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Q3tz7oZZtTT93tVYdET0xg1omALOvZvPNYNKQRp9i4o=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-yzFf+O\/mlH+Q9klUSqXP2kxGKOUFLPxaww8da8fKhGU=",
      "url": "sample-data\/weather.json"
    },
    {
      "hash": "sha256-ir9YCVnnk7popgsYUkvitfGA4WpkP1ydPh\/ENHnxGys=",
      "url": "_framework\/dotnet.timezones.blat"
    },
    {
      "hash": "sha256-YXYNlLeMqRPFVpY2KSDhleLkNk35d9KvzzwwKAoiftc=",
      "url": "_framework\/dotnet.wasm"
    },
    {
      "hash": "sha256-m7NyeXyxM+CL04jr9ui1Z6pVfMWwhHusuz5qNZWpAwA=",
      "url": "_framework\/icudt.dat"
    },
    {
      "hash": "sha256-91bygK5voY9lG5wxP0\/uj7uH5xljF9u7iWnSldT1Z\/g=",
      "url": "_framework\/icudt_CJK.dat"
    },
    {
      "hash": "sha256-DPfeOLph83b2rdx40cKxIBcfVZ8abTWAFq+RBQMxGw0=",
      "url": "_framework\/icudt_EFIGS.dat"
    },
    {
      "hash": "sha256-oM7Z6aN9jHmCYqDMCBwFgFAYAGgsH1jLC\/Z6DYeVmmk=",
      "url": "_framework\/icudt_no_CJK.dat"
    },
    {
      "hash": "sha256-WS05RNygETTzJa6IrHiyyVLJPZpiosV319Lgm41Sv48=",
      "url": "_framework\/dotnet.5.0.12.js"
    },
    {
      "hash": "sha256-GJ7ntxC4hcNZ8QIJPr+t+n9KxEUc2k1Oxo\/BY0DfptI=",
      "url": "Fahrzeugkunde.styles.css"
    },
    {
      "hash": "sha256-J3yBtIuvF38lccTVcUS7ScUgk93ATgKN6kbpbFM9JA0=",
      "url": "_content\/Blazored.Typeahead\/blazored-typeahead.css"
    },
    {
      "hash": "sha256-ClIzMmBI5Nozgt7KRG3K3u45r2pMtn\/X9Vx2UeudOPU=",
      "url": "_content\/Blazored.Typeahead\/blazored-typeahead.js"
    },
    {
      "hash": "sha256-UzBX1AnzM7b98cHBNoqM3Q7GKD9ImW4RKOGV8cPMZHI=",
      "url": "_framework\/Blazored.Typeahead.dll"
    },
    {
      "hash": "sha256-Z\/zw05S1Wz\/t+oFmyVOVSUsCJmS9OGVdYxBYnrpNBvQ=",
      "url": "_framework\/Microsoft.AspNetCore.Components.dll"
    },
    {
      "hash": "sha256-9evkF44akZ\/hxakj9REftmN2PIEYmlaolPPaT3jB3p0=",
      "url": "_framework\/Microsoft.AspNetCore.Components.Forms.dll"
    },
    {
      "hash": "sha256-78l628yj51EyoiysZ\/h1hEkad2skihAqOWuHlHSlX8c=",
      "url": "_framework\/Microsoft.AspNetCore.Components.Web.dll"
    },
    {
      "hash": "sha256-JVkYXLuEzAp5O0O0zcGBVkfktW5l1F3xyvH12EaEZOQ=",
      "url": "_framework\/Microsoft.AspNetCore.Components.WebAssembly.dll"
    },
    {
      "hash": "sha256-bZZ69\/58+BnN9G33FpTd2iXAdfgLbBnDUiiKxfaZ7IU=",
      "url": "_framework\/Microsoft.Extensions.Configuration.dll"
    },
    {
      "hash": "sha256-7mxFRRlriJzO95ZBz4cmDSFADogdaoDy8MxzQoNtwaU=",
      "url": "_framework\/Microsoft.Extensions.Configuration.Abstractions.dll"
    },
    {
      "hash": "sha256-cwzKuqTaJjYc5QXknt6NaBt\/MWSt9DYHfmu0I\/CV2mc=",
      "url": "_framework\/Microsoft.Extensions.Configuration.Json.dll"
    },
    {
      "hash": "sha256-MkujZ2O91jcr9W7eZzr22Fso+qza0R22PIDvFb\/fJVo=",
      "url": "_framework\/Microsoft.Extensions.DependencyInjection.dll"
    },
    {
      "hash": "sha256-AjnkOnqoQDS4FBQ7U5SmjPIthDVSq5uP1l6ACz+CUVw=",
      "url": "_framework\/Microsoft.Extensions.DependencyInjection.Abstractions.dll"
    },
    {
      "hash": "sha256-TpIA498zSsaZAjS+42XzHSmeWdSuY4\/\/ydfZQGlz1O8=",
      "url": "_framework\/Microsoft.Extensions.Logging.dll"
    },
    {
      "hash": "sha256-OsmdQoFiNmpqW0WHVklQ4R5\/fLVeqFPmPBRQzZxxufQ=",
      "url": "_framework\/Microsoft.Extensions.Logging.Abstractions.dll"
    },
    {
      "hash": "sha256-g1C9Fnh++M4k1mLduCz2yUnf\/70tTCbdZ\/s6bDjsmZM=",
      "url": "_framework\/Microsoft.Extensions.Options.dll"
    },
    {
      "hash": "sha256-32yXMbcCMbfUq7vtlIPput8uO7SZK8E9m3V8EXMScBc=",
      "url": "_framework\/Microsoft.Extensions.Primitives.dll"
    },
    {
      "hash": "sha256-TR5hDhis1xKErFGi0z7WTfCvkHgS9BWrl9meUe7pJ1M=",
      "url": "_framework\/Microsoft.JSInterop.dll"
    },
    {
      "hash": "sha256-ZgZxgsJuivJx1FZBYEZrIMDwbVwRAg9xRMD7wCwEQUM=",
      "url": "_framework\/Microsoft.JSInterop.WebAssembly.dll"
    },
    {
      "hash": "sha256-dynSyVRw634jYoxRfV3ogqFeCGZk7RFbdDmfT1x04F0=",
      "url": "_framework\/Newtonsoft.Json.dll"
    },
    {
      "hash": "sha256-qZYTUS+ga7CydtH54fYPbehFCvx3B49I74G8dxreTog=",
      "url": "_framework\/System.IO.Pipelines.dll"
    },
    {
      "hash": "sha256-ra3OFQZvEFlRhFKbmpGsHgUmg5NEcFWWSH5OJjLOz7U=",
      "url": "_framework\/Fahrzeugkunde.dll"
    },
    {
      "hash": "sha256-Lz3ZOduIBiJjsYuf9MZnx4Sw9eIYRwhf0jh6ptaArAo=",
      "url": "_framework\/System.Collections.Concurrent.dll"
    },
    {
      "hash": "sha256-PaTR6ElJn2hDTTfVR0G8wIAQ2S2dETGa1QeiUY17kBc=",
      "url": "_framework\/System.Collections.Immutable.dll"
    },
    {
      "hash": "sha256-HXf+jbNjGHYOr09FnhU6Qy69AwZfW6mr1294LLOzyfE=",
      "url": "_framework\/System.Collections.NonGeneric.dll"
    },
    {
      "hash": "sha256-6fcfZyP10MlhRf3UFnXSDJYUqrSpUOowjobTs\/6ABNI=",
      "url": "_framework\/System.Collections.Specialized.dll"
    },
    {
      "hash": "sha256-G3V4V+Qokt+310t7CoRkSckpJ6VlXmSbQ2otKkqFNgc=",
      "url": "_framework\/System.Collections.dll"
    },
    {
      "hash": "sha256-CTxGzPCcBdkJJgN29Ug9kxJeYv32KMP2XMLxZ1QCqiE=",
      "url": "_framework\/System.ComponentModel.Primitives.dll"
    },
    {
      "hash": "sha256-Dbr0pbZdMAOMXa7nR5OTHKHp\/NCG4blCYPOHxbIa798=",
      "url": "_framework\/System.ComponentModel.TypeConverter.dll"
    },
    {
      "hash": "sha256-992QOorVm9pdItb9fRFoTaRSqx4hz0bPMKq7aKD3p6w=",
      "url": "_framework\/System.ComponentModel.dll"
    },
    {
      "hash": "sha256-Und4J2DrvnIKdmkXUjEhcjVwWvUc8at1YETSMMWaYVw=",
      "url": "_framework\/System.Console.dll"
    },
    {
      "hash": "sha256-+36cJshH59DtrDGzVjT0awBY9ld6JYavgnxbXFp6A+Q=",
      "url": "_framework\/System.Data.Common.dll"
    },
    {
      "hash": "sha256-i0LdCKm3k2zP4QOG13ER7KI27pRk2eymo9lJStvXM2U=",
      "url": "_framework\/System.Diagnostics.TraceSource.dll"
    },
    {
      "hash": "sha256-o9zenN60lUj1hYSb84J4C8eeguSc\/qYnChl8ilBURtI=",
      "url": "_framework\/System.Drawing.Primitives.dll"
    },
    {
      "hash": "sha256-iEgyamBMlWdMWmiLvkSd1lmM9qslotwAkuIPB3j\/T7Y=",
      "url": "_framework\/System.IO.FileSystem.dll"
    },
    {
      "hash": "sha256-OSWsZ6Dp9RF\/S4bBAxNpshV7Asmm3rqw4naLFNYYtFQ=",
      "url": "_framework\/System.Linq.Expressions.dll"
    },
    {
      "hash": "sha256-CTm5IXVfuFKmaMCzlq4x73MohvtjTybKiVpaEXyeWNQ=",
      "url": "_framework\/System.Linq.dll"
    },
    {
      "hash": "sha256-uP5t1YUOHsLZM1FmPokMCxrkf5HRaLQfFaiSrHYsSyk=",
      "url": "_framework\/System.Memory.dll"
    },
    {
      "hash": "sha256-v8067of0NycS4K67i+aKZIgCtOTw4LSQj3mkYv8FRz8=",
      "url": "_framework\/System.Net.Http.Json.dll"
    },
    {
      "hash": "sha256-H2W8Ev34d42Y9EU9nBpBIjtaFHV1xZ4psavYKVDcXgc=",
      "url": "_framework\/System.Net.Http.dll"
    },
    {
      "hash": "sha256-hb0+IqSvWJcfYi4m9rIWfdaOFFTsajLGgU4lpLBMSvc=",
      "url": "_framework\/System.Net.Primitives.dll"
    },
    {
      "hash": "sha256-\/u88uAjUDyb8QPHMH8NWTgr38aY2KtH0kiu3ruhtsCQ=",
      "url": "_framework\/System.ObjectModel.dll"
    },
    {
      "hash": "sha256-GLin8MOD\/IEQyMQsmzM+xcN2o5wJlP3OBjc5Bc0vBJU=",
      "url": "_framework\/System.Private.Runtime.InteropServices.JavaScript.dll"
    },
    {
      "hash": "sha256-3F7e8GTbHkw\/tCY9gFR4SMDY02JDEmOWjIfmnX9KnJo=",
      "url": "_framework\/System.Private.Uri.dll"
    },
    {
      "hash": "sha256-RVd2L\/aKCYtRmtckp4dKb29hYDPWSvHZcIPDvgFo9Us=",
      "url": "_framework\/System.Private.Xml.Linq.dll"
    },
    {
      "hash": "sha256-Kd2pYhFF+PdAGhN5GVX3U9nzFFflq6ywGn16M2LYf7w=",
      "url": "_framework\/System.Private.Xml.dll"
    },
    {
      "hash": "sha256-GEySmGhtvGbv56DLJ\/JpZft8j0V0AGOjVxb9RLihJM4=",
      "url": "_framework\/System.Runtime.CompilerServices.Unsafe.dll"
    },
    {
      "hash": "sha256-Fi\/opQiEC89VkXba7O3mWPciajM8zJxPLytH39DE5mM=",
      "url": "_framework\/System.Runtime.InteropServices.RuntimeInformation.dll"
    },
    {
      "hash": "sha256-2koLKzEkgZbZJ\/vOTizq8yFRl1q0lJMOmoy5e\/zvbxo=",
      "url": "_framework\/System.Runtime.Numerics.dll"
    },
    {
      "hash": "sha256-vCvH3+iucjZTIg3YUVexk1ugeALQkFPfG4jCQpyBwSg=",
      "url": "_framework\/System.Runtime.Serialization.Formatters.dll"
    },
    {
      "hash": "sha256-tEpYzTVou9qkb2nZ+Bbe0XUxR2iVH8BX6JVjNS2C5xc=",
      "url": "_framework\/System.Runtime.Serialization.Primitives.dll"
    },
    {
      "hash": "sha256-EGHH1zRt7P83rW07AkHlCzaua55M+PyFwCl0pcb+yqg=",
      "url": "_framework\/System.Security.Cryptography.Algorithms.dll"
    },
    {
      "hash": "sha256-5G5fWLAre5QkeTjx3LNhRf0hot\/ikOlhSTyCGT\/LSOU=",
      "url": "_framework\/System.Text.Encodings.Web.dll"
    },
    {
      "hash": "sha256-DITuS86JcF1JRjAgyG1lAwUOR6sBWXHPO06SeEn9c0w=",
      "url": "_framework\/System.Text.Json.dll"
    },
    {
      "hash": "sha256-4hPgvJicU96kNWoTIfhf5Yq+FapCGtK0aSKfC64c7Is=",
      "url": "_framework\/System.Text.RegularExpressions.dll"
    },
    {
      "hash": "sha256-JF\/Z+M3At8ID8FyrGod4u5wkc4GM\/hVGfGJM5z9BeD0=",
      "url": "_framework\/System.Private.CoreLib.dll"
    },
    {
      "hash": "sha256-oS0It8SvGhu28taG3i+hkOC+dvDySHiYSZ\/7OYqyQFw=",
      "url": "_framework\/blazor.boot.json"
    },
    {
      "hash": "sha256-dl8FVRvWOJfOtzIC\/x66QNnBNsT9cAOMrn22GB8fJ8U=",
      "url": "_framework\/blazor.webassembly.js"
    }
  ],
  "version": "lkHQVrs3"
};
