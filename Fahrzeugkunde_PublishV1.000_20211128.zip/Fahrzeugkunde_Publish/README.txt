# Find  -  Fahrzeugkunde
ENG:
Little programm for showing pictures to find objects, for example in a fire engine. Therefore the user has to save pictures in a .xlsx file and mark the later clickable areas with frames.

A detailed Englisch description will follow as soon as I find the time to do it.

The Software is free to use for private and noncommercial Organizations.
If you want to support the project, you open Amazon with the Affiliate Link below. And then buy whatever you wish. The product will not be more expensive for you, but I will get a little percantage.

Affiliate Link to Amazon: 
https://www.amazon.de/gp/product/3555015842/ref=as_li_tl?ie=UTF8&camp=1638&creative=6742&creativeASIN=3555015842&linkCode=as2&tag=progfind-21&linkId=f8a5da7b923587427f4bad71094882ef
         
https://www.patreon.com/ProgFind"

Thank you and have fun

This project was made possible by using:
EPPLUS
Blazored.Typeahead
Newtonsoft.Json

Deutsch:

Kleines Programm um Objekte auf Bildern anzuzeigen, zum Beispiel in einem Feuerwehrfahrzeug. Die Parametrierung erfolgt über .xlsx Dateien durch einfaches einfügen der Bilder und Markierung der einzelnen Bereiche mit Rahmen.

Die Software stelle ich zum privaten und auch ehrenamtlichen Gebrauch (Nichkommerzielle Organisationen) kostenlos zur Verfügung.
Wer das Projekt trotzdem unterstützen möchte, geht einfach beim nächsten Amazon Einkauf über den Affiliate Link auf die Amazon Seite. Gekauft werden kann das gesamte Amazon Sortiment. Das Produkt wird dadurch nicht teurer, doch ich erhalte eine kleine Provision.
Hier der Affiliate Link:
https://www.amazon.de/gp/product/3555015842/ref=as_li_tl?ie=UTF8&camp=1638&creative=6742&creativeASIN=3555015842&linkCode=as2&tag=progfind-21&linkId=f8a5da7b923587427f4bad71094882ef

Alternativ direkt unterstützen über Patreon:
https://www.patreon.com/ProgFind

Danke und viel Spass beim Suchen und Finden.

Verwendete Pakete:
EPPLUS
Blazored.Typeahead
Newtonsoft.Json

Copyright (c) 2021 ProgFind


